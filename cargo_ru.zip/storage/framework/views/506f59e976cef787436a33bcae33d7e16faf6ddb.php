<div class="question panel panel-primary cursor-pointer"
    data-question-id="<?php echo e($question->id); ?>"
    data-toggle="modal"
    data-target="#question-modal"
    onclick="LoadQuestionModal(<?php echo e($question->id); ?>)">

    <div class="panel-heading">
        <input type="checkbox" <?php echo e($question->solved ? "checked" : ""); ?> disabled class="question-solved-checkbox">
        <?php echo e($question->text); ?>

    </div>

    <div class="panel-body">Ответов: <b class="answers-count" data-question-id="<?php echo e($question->id); ?>"><?php echo e($question->answers->count()); ?></b>... Вопрос опубликован: <?php echo e($question->created_at); ?></div>

</div>