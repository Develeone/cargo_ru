<ul class="nav nav-tabs">
    <?php for($i = 0; $i < $categories->count(); $i++): ?>
        <li class="<?php echo e($i == 0 ? 'active' : ''); ?>"><a data-toggle="tab" href="#<?php echo e($categories[$i]->name); ?>"><?php echo e($categories[$i]->name); ?></a></li>
    <?php endfor; ?>
</ul>

<div class="tab-content">

    <?php for($category_i = 0; $category_i < $categories->count(); $category_i++): ?>
    <div id="tab1" class="tab-pane fade <?php echo e($i == 0 ? 'in active' : ''); ?>">
        <?php $__currentLoopData = $categories[$category_i]->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="panel panel-primary">
                <div class="panel-heading"><input type="checkbox"> Question <?php echo e($i); ?> header text</div>
                <div class="panel-body">Question 1 some details goes here</div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endfor; ?>
</div>