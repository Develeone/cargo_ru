<?php $__env->startSection('content'); ?>

    <div class="row top-buffer">
        <div class="col-md-2">
            <?php echo $__env->make('includes.left_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-8">
            <?php echo $__env->yieldContent('questions'); ?>
        </div>
        <div class="col-md-2">
            <?php echo $__env->make('includes.right_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>