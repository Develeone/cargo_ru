<?php $__env->startSection('questions'); ?>
    <ul class="nav nav-tabs">
        <?php for($i = 0; $i < $categories->count(); $i++): ?>
            <li class="<?php echo e($i == 0 ? 'active' : ''); ?>">
                <a data-toggle="tab" href="#<?php echo e($categories[$i]->name); ?>"><?php echo e($categories[$i]->name); ?></a>
            </li>
        <?php endfor; ?>
    </ul>

    <div class="tab-content">

        <?php for($category_i = 0; $category_i < $categories->count(); $category_i++): ?>
        <div id="<?php echo e($categories[$category_i]->name); ?>" class="tab-pane fade <?php echo e($category_i == 0 ? 'in active' : ''); ?>">
            <?php $__currentLoopData = $categories[$category_i]->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('includes.question', ["question" => $question], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endfor; ?>
    </div>

    <?php echo $__env->make('includes.question_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.new_question_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebars', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>