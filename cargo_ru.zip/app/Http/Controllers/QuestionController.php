<?php

namespace App\Http\Controllers;

use App\Question;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class QuestionController extends Controller
{
    function show ($questionId) {
        return Question::where('id', $questionId)
            ->with('answers')
            ->first();
    }

    function create (Request $request) {
        $newQuestion = new Question($request->all());//::create($request->all());
        Auth::user()->questions()->save($newQuestion);

/*        $newQuestion->text = $request->question_text;
        $newQuestion->category_id = $request->category_id;
        $newQuestion->owner = Auth::id();
        $newQuestion->solved = false;
*/
        return $request;
    }
}
