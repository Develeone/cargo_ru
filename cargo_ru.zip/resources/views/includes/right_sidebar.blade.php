<H4>Right sidebar</H4>
<div class="row">
    <div class="col-lg-12 ads-container">
        <h1>ADS</h1>
    </div>
</div>