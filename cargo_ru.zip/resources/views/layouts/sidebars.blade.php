@extends('layouts.app')

@section('content')

    <div class="row top-buffer">
        <div class="col-md-2">
            @include('includes.left_sidebar')
        </div>
        <div class="col-md-8">
            @yield('questions')
        </div>
        <div class="col-md-2">
            @include('includes.right_sidebar')
        </div>
    </div>

@endsection
