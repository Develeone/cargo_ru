@extends('layouts.sidebars')

@section('questions')
    <ul class="nav nav-tabs">
        @for($i = 0; $i < $categories->count(); $i++)
            <li class="{{$i == 0 ? 'active' : ''}}">
                <a data-toggle="tab" href="#{{$categories[$i]->name}}">{{$categories[$i]->name}}</a>
            </li>
        @endfor
    </ul>

    <div class="tab-content">

        @for($category_i = 0; $category_i < $categories->count(); $category_i++)
        <div id="{{$categories[$category_i]->name}}" class="tab-pane fade {{$category_i == 0 ? 'in active' : ''}}">
            @foreach($categories[$category_i]->questions as $question)
                @include('includes.question', ["question" => $question])
            @endforeach
        </div>
        @endfor
    </div>

    @include('includes.question_modal')
    @include('includes.new_question_modal')
@endsection