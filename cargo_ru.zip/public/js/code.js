$("#new-answer").submit(function (e) {
    e.preventDefault();

    $.post('/answer/new', $(this).serialize(), function (question_id) {
        LoadQuestionModal(question_id);

        var answers_counter = $(".question[data-question-id='"+question_id+"'] .answers-count");
        var question_solved_checkbox = $(".question[data-question-id='"+question_id+"'] .question-solved-checkbox");

        var answers_count = parseInt(answers_counter.html());
        answers_counter.html(++answers_count);

        if (answers_count >= 10)
            question_solved_checkbox.attr('checked', 'checked');
    });
});

$("#new-question").submit(function (e) {
    e.preventDefault();

    $.post('/question/new', $(this).serialize(), function (data) {
        location.reload();
    });
});

function LoadQuestionModal (questionId) {
    $.get('/question/'+questionId, function (question) {
        // Set question text
        $("#question-modal #question-text").html(question.text);

        // Set answers
        var answersHtml = "";
        for (var i = 0; i < question.answers.length; i++)
            answersHtml += "<li>" + question.answers[i].text + "</li>";

        $("#question-modal #answers-container").html(answersHtml);

        // Set new answer form
        var newAnswerForm = $("#question-modal #new-answer");

        var isUserAnswerExists = question.answers.filter(function( obj ) {
            return obj.owner == auth_id;
        }).length;

        // Show or hide new answer form
        if (!auth_id || question.owner == auth_id || isUserAnswerExists || question.answers.length >= 10)
            newAnswerForm.addClass('hidden');
        else
            newAnswerForm.removeClass('hidden');

        // Set the hidden "question_id" input field
        $("#question-modal #question-id").val(question.id);
    })
}